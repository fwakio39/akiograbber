import requests
from configparser import ConfigParser
import time
from colorama import Fore, Style, init
import json
import keyboard
from time import sleep
from pynput import keyboard
from threading import Thread
import sys
import os
import colorama
from colorama import Fore
import random, json
import requests, websocket
import string, pyautogui
import ctypes, os, sys
import time, threading
import datetime


# credits: stxnch (helped with getting header), hay42 (created full source, updated api code, imported config & more)
# to get better paid tools for discord please go to https://discord.gg/boostaworld

#initalize colorama
init()

config_file = 'config.json' # load config
config = json.load(open(config_file, 'r')) # allows us to call var config using config[Info]

token = config['Info']['token'] # creates token variable from config
guildId = config['Info']['serverid'] # creates guild var from config
webhook_url = config['Info']['webhookUrl'] # gets wwebhook url from config
vanityUrl = config['Info']['vanity'] # gets invite from config

header = {
          "authorization": token,
          "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36"
}

def checkVanity():
    while True:
        try:
            if vanityUrl == "boostaworld":
                print(f'{Fore.RED} You CANNOT snipe this vanity. It belongs to hay42. Please edit config and retry')
                sleep(5)
            else: 
                response = requests.get(f"https://discord.com/api/v9/invites/{vanityUrl}?with_counts=true&with_expiration=true", 
                                        headers=header)
                if response.status_code == 404:
                    print(f'{Fore.GREEN} Claiming vanity: {vanityUrl}')
                    changeVanity()
                else:
                    print(f'{Fore.RED} Vanity URL still active: {vanityUrl}')

            time.sleep(0) #sleep from ratelimit 
        except Exception as e:
            e
            print(f'{Fore.RED} Rate Limited. Sleeping')
            time.sleep(2)
            
def changeVanity():
    payload = {"code": vanityUrl}
    response = requests.patch(f'https://discord.com/api/v9/guilds/{guildId}/vanity-url', 
                              headers=header, 
                              json=payload)

    if response.status_code == 200:
        print(f'{Fore.GREEN} Vanity URL changed: {vanityUrl}')
        data = {
                'content': f"@everyone discord.gg/{vanityUrl} yours now!",
                'username': "Hay Testa",
                'avatar_url': "https://i.imgur.com/oKzncfw.png"
    }
    response = requests.post(url=webhook_url, json=data)
    print("webhook sent!")

def tool():
      os.system('cls' if os.name=='nt' else 'clear')

init()

global options1
def options1():

    
    os.system('cls')
ctypes.windll.kernel32.SetConsoleTitleW(f".gg/boostaworld | Login | Vanity Sniper | Creator: hay42")
print(f'''
    {Fore.MAGENTA}__________                       __                            .__       .___ 
    {Fore.MAGENTA}\______   \ ____   ____  _______/  |______ __  _  _____________|  |    __| _/
    {Fore.MAGENTA} |    |  _//  _ \ /  _ \/  ___/\   __\__  \\ \/ \/ /  _ \_  __ \  |   / __ | 
    {Fore.LIGHTMAGENTA_EX} |    |   (  <_> |  <_> )___ \  |  |  / __ \\     (  <_> )  | \/  |__/ /_/ | 
    {Fore.LIGHTMAGENTA_EX} |______  /\____/ \____/____  > |__| (____  /\/\_/ \____/|__|  |____/\____ | 
    {Fore.LIGHTMAGENTA_EX}         \/                  \/            \/                              \/   
    ''')              
print(f'{Fore.GREEN}Config Successfully Loaded! {Fore.RESET} {Fore.LIGHTCYAN_EX}')        
input(f'Click enter to start!')
if input:
    os.system('cls')
    ctypes.windll.kernel32.SetConsoleTitleW(f".gg/boostaworld | Initializing | Vanity Sniper | Creator: hay42")
    print("Key Clicked!\nWait 2 seconds..")
    sleep(1)
    os.system('cls')
    print("Key Clicked!\nWait 1 seconds..")
    sleep(1)
    os.system('cls')
    print(f'Starting now!')
    sleep(.5)
    os.system('cls')

ctypes.windll.kernel32.SetConsoleTitleW(f".gg/boostaworld | Vanity Sniper | Sniping | Creator: hay42")

checkVanity()

tool()
while __name__ == '__main__':
    print(Fore.BLUE)
    os.system('pause')
    tool()